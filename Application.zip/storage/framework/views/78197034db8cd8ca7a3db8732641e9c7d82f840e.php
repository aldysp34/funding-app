<div class="navbar navbar-expand navbar-shadow px-0  pl-lg-16pt navbar-light bg-body" id="default-navbar" data-primary>

    <!-- Navbar toggler -->
    <button class="navbar-toggler d-block d-lg-none rounded-0"
            type="button"
            data-toggle="sidebar">
        <span class="material-icons">menu</span>
    </button>

    <!-- Navbar Brand -->
    <div
        class="navbar-brand mr-16pt d-lg-none">
        <img class="navbar-brand-icon mr-0 mr-lg-8pt"
            src="<?php echo e(asset('assets/images/logo/accent-teal-100@2x.png')); ?>"
            width="32"
            alt="Huma">
        <span class="d-none d-lg-block">Huma</span>
    </div>

    <!-- <button class="btn navbar-btn mr-16pt" data-toggle="modal" data-target="#apps">Apps <i class="material-icons">arrow_drop_down</i></button> -->


    <div class="flex"></div>


    <div class="nav navbar-nav flex-nowrap d-flex ml-0 mr-16pt">
        <div class="nav-item dropdown d-none d-sm-flex">
            <a href="#"
                class="nav-link d-flex align-items-center dropdown-toggle"
                data-toggle="dropdown">
                <span class="flex d-flex flex-column mr-8pt">
                    <span class="navbar-text-100"><?php echo $__env->yieldContent('name'); ?></span>
                    <small class="navbar-text-50"><?php echo $__env->yieldContent('role'); ?></small>
                    <small class="navbar-text-50"><?php echo $__env->yieldContent('bidang'); ?></small>
                </span>
            </a>
            <div class="dropdown-menu dropdown-menu-right">
                <div class="dropdown-header"><strong>Account</strong></div>
                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();">Logout</a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
        </div>
    </div>
</div>
<?php /**PATH X:\Siji Solusi Digital\funding-app-alternate\Application\resources\views/layouts/partials/header.blade.php ENDPATH**/ ?>