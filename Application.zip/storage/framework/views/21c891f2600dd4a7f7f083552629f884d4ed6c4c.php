<div class="mdk-drawer js-mdk-drawer" id="default-drawer">
    <div class="mdk-drawer__content">
        <div class="sidebar sidebar-dark sidebar-left" data-perfect-scrollbar>
            <?php echo $__env->yieldContent('sidebar-content'); ?>
        </div>
    </div>
</div>
<?php /**PATH X:\Siji Solusi Digital\funding-app-alternate\Application\resources\views/layouts/partials/sidebar.blade.php ENDPATH**/ ?>