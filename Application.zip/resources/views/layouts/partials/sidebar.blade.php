<div class="mdk-drawer js-mdk-drawer" id="default-drawer">
    <div class="mdk-drawer__content">
        <div class="sidebar sidebar-dark sidebar-left" data-perfect-scrollbar>
            @yield('sidebar-content')
        </div>
    </div>
</div>
